﻿using Participent_BAL;
using Participent_Entity;
using Participent_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Participent_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private static P_Entity SearchPatientByID(string searchParticipentID)
        {
            P_Entity SearchedParticipent = new P_Entity();
            try
            {
                SearchedParticipent = P_BAL.SearchParticipentBL(searchParticipentID);
            }
            catch (P_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return SearchedParticipent;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string ParticipentNumber = txtVoucherNum.Text;
            P_Entity SearchedPatient = SearchPatientByID(ParticipentNumber);
            txtParticipentName.Text = SearchedPatient.ParticipentName;
            txtTechnology.Text = SearchedPatient.Technology;
            txtCertificationCode.Text = SearchedPatient.CertificationCode;
            txtCertificationName.Text = SearchedPatient.CertificationName;
            txtCertificationDate.Text = SearchedPatient.CertificationDate.ToString();
        }
    }
}
