﻿using Participent_DAL;
using Participent_Entity;
using Participent_Exception;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Participent_BAL
{
    public class P_BAL
    {
        private static bool ValidateParticipent(string vid)
        {
            bool isValidparticipent = true;
            StringBuilder sbPMSError = new StringBuilder();
            P_Entity p = new P_Entity();

            //if (!(Regex.IsMatch(p.FistName, "[A-Z][a-z]{3,}")))
            //{
            //    isValidpatient = false;
            //    sbPMSError.Append("patient Name must have only characters starting with uppercase " + Environment.NewLine);
            //}


            //if (!(Regex.IsMatch(p.PhoneNumber.ToString(), "^[6-9][0-9]{9}$")))
            //{
            //    isValidpatient = false;
            //    sbPMSError.Append("Patient contact should have 10 digits or First digit should be greater than 6" + Environment.NewLine);
            //}

            //if (!(Regex.IsMatch(newPatient.PinCode.ToString(), "^{6}$")))

            //{
            //    isValidpatient = false;
            //    sbPMSError.Append("PinCode should have 6 digits" + Environment.NewLine);

            //}

            if (String.IsNullOrEmpty(p.VoucherNumber))
            {
                sbPMSError.Append("VoucherNumber doesn't Exist" + Environment.NewLine);
            }
            if (!isValidparticipent)

            { throw new P_Exception(sbPMSError.ToString()); }

            return isValidparticipent;
        }


        public static P_Entity SearchParticipentBL(string searchParticipentID)
        {
            P_Entity searchParticipent = null;
            if (ValidateParticipent(searchParticipentID))
            {
               
                try
                {
                    P_DAL p_DAL = new P_DAL();
                    searchParticipent = p_DAL.SearchParticipentDAL(searchParticipentID);
                }
                catch (P_Exception ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return searchParticipent;

        }
    }

}