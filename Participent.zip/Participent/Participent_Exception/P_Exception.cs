﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Participent_Exception
{

    [Serializable]
    public class P_Exception : Exception
    {
        public P_Exception() { }
        public P_Exception(string message) : base(message) { }
        public P_Exception(string message, Exception inner) : base(message, inner) { }
        protected P_Exception(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
