﻿using Participent_Entity;
using Participent_Exception;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Participent_DAL
{
    public class P_DAL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static P_DAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public P_DAL()
        {
            con = new SqlConnection(conStr);

        }
        
        public P_Entity SearchParticipentDAL(string searchParticipentID)
        {
            P_Entity SearchedPatient = new P_Entity();
            try
            {
                con.ConnectionString = conStr;
                con.Open();
               cmd = new SqlCommand();
                cmd.Connection = con;
                string query = "SearchParticipent_172536";
                cmd.Parameters.AddWithValue("@VoucherNumber", searchParticipentID);
                cmd.CommandText = query;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = cmd.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        SearchedPatient.VoucherNumber = Reader[0].ToString();
                        SearchedPatient.ParticipentName = Reader[1].ToString();
                        SearchedPatient.Technology = Reader[2].ToString();
                        SearchedPatient.CertificationCode = Reader[3].ToString();
                        SearchedPatient.CertificationName = Reader[4].ToString();
                        SearchedPatient.CertificationDate = Convert.ToDateTime(Reader[5].ToString());
                    }
                }
                   
              
            }
            catch (P_Exception)
            {
                throw;
            }
            return SearchedPatient;
        }

    }
}
